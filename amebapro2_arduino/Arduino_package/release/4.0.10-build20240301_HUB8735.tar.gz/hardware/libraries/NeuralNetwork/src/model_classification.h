#ifndef MODEL_CLASSIFICATION_H
#define MODEL_CLASSIFICATION_H

#include "module_vipnn.h"

extern nnmodel_t img_classification;
#endif
