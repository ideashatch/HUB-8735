#ifndef _WEB_CONTROL_SAMPLE_H_
#define _WEB_CONTROL_SAMPLE_H_

void streaming_httpd(struct httpd_conn *conn);

#define PART_BOUNDARY_THD "123456789000000000000987654321"

extern char* STREAM_BOUNDARY_THD;
extern char* IMG_HEADER_THD;
extern uint32_t img_addr_THD;
extern uint32_t img_len_THD;

#endif
