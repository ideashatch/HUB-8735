#ifndef b64_h
#define b64_h

int b64_encode(const unsigned char* aInput, int aInputLen, unsigned char* aOutput, int aOutputLen);

#endif
