#ifndef DEFINES_H
#define DEFINES_H

#define ToVectorMem(x) (*((__m64*)&(x)))

#endif
