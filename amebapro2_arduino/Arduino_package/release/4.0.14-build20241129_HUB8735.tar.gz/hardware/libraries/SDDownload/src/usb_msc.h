#ifndef _EXAMPLE_MASS_STORAGE_H
#define _EXAMPLE_MASS_STORAGE_H

void MSC_INIT(void);
void MSC_DEINIT(void);

#endif /* _EXAMPLE_MASS_STORAGE_H */

