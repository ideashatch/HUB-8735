typedef struct IDV3
{
     char Header[3];    /*必须为“ID3”否则认为标签不存在*/
     char Ver;          /*版本号ID3V2.3 就记录3*/
     char Revision;     /*副版本号此版本记录为0*/
     char Flag;         /*标志字节，只使用高三位，其它位为0 */
     char Size[4];      /*标签大小*/
}mp3IDV3;

typedef struct TAG
{
     char Header[4];    /*必须为“ID3”否则认为标签不存在*/
     char Size[4];      /*标签大小*/
     char Flag[2];
}mp3TAG;

typedef struct FrameHeader
{
  unsigned int sync;                        //同步信息
  unsigned int version;                      //版本
  unsigned int layer;                           //层
  unsigned int error_protection;           // CRC校验
  unsigned int bitrate_index;              //位率
  unsigned int sampling_frequency;         //采样频率
  unsigned int padding;                    //帧长调节
  unsigned int private_word;                       //保留字
  unsigned int mode;                         //声道模式
  unsigned int mode_extension;        //扩充模式
  unsigned int copyright;                           // 版权
  unsigned int original;                      //原版标志
  unsigned int emphasis;                  //强调模式
}FHEADER;

#define tag_size unsigned int