#ifndef _EXAMPLE_AUDIO_HELIX_MP3_H_
#define _EXAMPLE_AUDIO_HELIX_MP3_H_


void audio_helix_mp3(void);
int parseMP3();
void setOutputGain(uint8_t u8_gain);
extern unsigned int mp3_data_len;// = sizeof(mp3_data);
extern uint8_t audio_output_gain;
SDRAM_DATA_SECTION extern unsigned char *mp3_data;
#endif